/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.gymmanager.model;

import java.util.Date;

/**
 * A classe Aluno herda todos os atributos de Pessoa e adiciona
 * informações específicas de um aluno da academia.
 */
public class Aluno extends Pessoa {

    private String plano;
    private Date dataMatricula;
    private boolean statusPagamentoEmDia;

    // Construtor vazio
    public Aluno() {
        super(); // Chama o construtor da classe pai (Pessoa)
    }

    // Construtor com todos os campos
    public Aluno(int id, String nome, String cpf, String telefone, String email, String plano, Date dataMatricula, boolean statusPagamentoEmDia) {
        // 'super(...)' chama o construtor da classe Pessoa para preencher os dados herdados
        super(id, nome, cpf, telefone, email); 
        this.plano = plano;
        this.dataMatricula = dataMatricula;
        this.statusPagamentoEmDia = statusPagamentoEmDia;
    }
    
    // --- Getters e Setters dos atributos específicos de Aluno ---

    public String getPlano() {
        return plano;
    }

    public void setPlano(String plano) {
        this.plano = plano;
    }

    public Date getDataMatricula() {
        return dataMatricula;
    }

    public void setDataMatricula(Date dataMatricula) {
        this.dataMatricula = dataMatricula;
    }

    public boolean isStatusPagamentoEmDia() {
        return statusPagamentoEmDia;
    }

    public void setStatusPagamentoEmDia(boolean statusPagamentoEmDia) {
        this.statusPagamentoEmDia = statusPagamentoEmDia;
    }
}