package br.com.gymmanager.dao;

import br.com.gymmanager.model.Funcionario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate; // ADICIONAR ESTA IMPORTAÇÃO
import java.sql.Date;       // ADICIONAR ESTA IMPORTAÇÃO

import javax.swing.JOptionPane;

public class FuncionarioDAO {
    
    // Método auxiliar para mapear o ResultSet para o objeto Funcionario,
    // garantindo a conversão de java.sql.Date para LocalDate.
    private Funcionario mapResultSetToFuncionario(ResultSet rset) throws SQLException {
        Funcionario func = new Funcionario();
        func.setId(rset.getInt("id_funcionario"));
        func.setNome(rset.getString("nome"));
        func.setCpf(rset.getString("cpf"));
        
        // CONVERSÃO DE DATA: java.sql.Date do banco para LocalDate do Model
        Date sqlDataNascimento = rset.getDate("data_nascimento");
        if (sqlDataNascimento != null) {
            func.setDataNascimento(sqlDataNascimento.toLocalDate());
        }

        func.setTelefone(rset.getString("telefone"));
        func.setEmail(rset.getString("email"));
        func.setCargo(rset.getString("cargo"));
        
        // CONVERSÃO DE DATA: java.sql.Date do banco para LocalDate do Model
        Date sqlDataAdmissao = rset.getDate("data_admissao");
        if (sqlDataAdmissao != null) {
            func.setDataAdmissao(sqlDataAdmissao.toLocalDate());
        }

        func.setSenha(rset.getString("senha")); 
        func.setCaminhoFoto(rset.getString("caminho_foto"));
        return func;
    }
    
    public boolean cadastrar(Funcionario func) {
        String sql = "INSERT INTO funcionarios (nome, cpf, data_nascimento, telefone, email, cargo, data_admissao, senha, caminho_foto) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);

            pstm.setString(1, func.getNome());
            pstm.setString(2, func.getCpf());
            
            // CONVERSÃO DE DATA: LocalDate do Model para java.sql.Date
            LocalDate dataNasc = func.getDataNascimento();
            pstm.setDate(3, dataNasc != null ? Date.valueOf(dataNasc) : null);
            
            pstm.setString(4, func.getTelefone());
            pstm.setString(5, func.getEmail());
            pstm.setString(6, func.getCargo());
            
            // CONVERSÃO DE DATA: LocalDate do Model para java.sql.Date
            LocalDate dataAdm = func.getDataAdmissao();
            pstm.setDate(7, dataAdm != null ? Date.valueOf(dataAdm) : null);

            // Mantendo a senha em texto puro, conforme o código original
            pstm.setString(8, func.getSenha()); 
            
            pstm.setString(9, func.getCaminhoFoto());
            
            pstm.execute();
            return true;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar funcionário: " + e.getMessage());
            return false;
        } finally {
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean atualizar(Funcionario func) {
        String sql = "UPDATE funcionarios SET nome = ?, cpf = ?, data_nascimento = ?, telefone = ?, email = ?, cargo = ?, data_admissao = ?, senha = ?, caminho_foto = ? " +
                     "WHERE id_funcionario = ?";

        Connection conn = null;
        PreparedStatement pstm = null;

        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);

            pstm.setString(1, func.getNome());
            pstm.setString(2, func.getCpf());
            
            // CONVERSÃO DE DATA: LocalDate do Model para java.sql.Date
            LocalDate dataNasc = func.getDataNascimento();
            pstm.setDate(3, dataNasc != null ? Date.valueOf(dataNasc) : null);
            
            pstm.setString(4, func.getTelefone());
            pstm.setString(5, func.getEmail());
            pstm.setString(6, func.getCargo());
            
            // CONVERSÃO DE DATA: LocalDate do Model para java.sql.Date
            LocalDate dataAdm = func.getDataAdmissao();
            pstm.setDate(7, dataAdm != null ? Date.valueOf(dataAdm) : null);

            // Mantendo a senha em texto puro, conforme o código original
            pstm.setString(8, func.getSenha());
            
            pstm.setString(9, func.getCaminhoFoto());
            pstm.setInt(10, func.getId());

            pstm.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar funcionario: " + e.getMessage());
            return false;
        } finally {
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean remover(int id) {
        String sql = "DELETE FROM funcionarios WHERE id_funcionario = ?";
        // ... (código do remover mantido, pois não usa datas)
        Connection conn = null;
        PreparedStatement pstm = null;

        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);

            pstm.setInt(1, id);

            pstm.execute();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover funcionário: " + e.getMessage());
            return false;
        } finally {
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e ) {
                e.printStackTrace();
            }
        }
    }

    public List<Funcionario> listarTodos() {
        String sql = "SELECT * FROM funcionarios";
        List<Funcionario> funcionarios = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;

        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);
            rset = pstm.executeQuery();

            while(rset.next()) {
                funcionarios.add(mapResultSetToFuncionario(rset)); // Usa o método auxiliar
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar funcionários: " + e.getMessage());
        } finally {
            try {
                if (rset != null) rset.close();
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return funcionarios;
    }
    
    // Método de Login - Retorna à lógica original de comparação de Strings
    public Funcionario verificarCredenciais(String cpf, String senha) {
        // SQL original que compara CPF e Senha em texto puro
        String sql = "SELECT * FROM funcionarios WHERE cpf = ? AND senha = ?"; 

        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;

        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);

            pstm.setString(1, cpf);
            pstm.setString(2, senha); // Senha em texto puro

            rset = pstm.executeQuery();

            if(rset.next()) {
                // Credenciais válidas, mapeia e retorna o funcionário.
                return mapResultSetToFuncionario(rset);
            } else {
                return null;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao validar credenciais: " + e.getMessage());
            return null;
        } finally {
            try {
                if(rset != null) rset.close();
                if(pstm != null) pstm.close();
                if(conn != null) conn.close();
            } catch (SQLException e) {
            e.printStackTrace();
            }
        }
    }
}