package br.com.gymmanager.view;

import br.com.gymmanager.dao.AlunoDAO;
import br.com.gymmanager.dao.PlanoDAO;
import br.com.gymmanager.model.Aluno;
import br.com.gymmanager.model.Plano;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TelaCadastroAluno extends JFrame {

    private static final Color COR_BRANCO = Color.WHITE;
    private AlunoDAO alunoDAO = new AlunoDAO();
    private PlanoDAO planoDAO = new PlanoDAO();
    private Aluno aluno;
    private TelaGestaoAlunos parent;
    private DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private TelaPrincipal telaPrincipalPai; // Adicione esta linha
    // NOVO CONSTRUTOR para ser chamado da TelaPrincipal
    public TelaCadastroAluno(TelaPrincipal pai) {
    // Inicializa a variável para a TelaPrincipal
    this.telaPrincipalPai = pai; 

    // Se a sua tela usa um método para inicializar, chame-o aqui
    // Exemplo: initComponents(); 

    // Configura para novo cadastro, já que não veio um Aluno
}
    
    
    private JTextField txtNome;
    private JFormattedTextField txtCpf;
    private JFormattedTextField txtDataNasc;
    private JTextField txtTelefone;
    private JTextField txtEmail;
    private JComboBox<Plano> comboPlano;
    private JTextField txtObjetivo;
    private JComboBox<String> comboStatus;
    private JFormattedTextField txtDataMatricula;

    public TelaCadastroAluno(TelaGestaoAlunos parent, Aluno aluno) {
        this.parent = parent;
        this.aluno = aluno;
        setTitle(aluno == null ? "Cadastrar Aluno" : "Editar Aluno");
        setSize(600, 520);
        setLocationRelativeTo(parent);

        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(new EmptyBorder(15,15,15,15));
        p.setBackground(COR_BRANCO);
        setContentPane(p);

        GridBagConstraints gbc = new GridBagConstraints(); gbc.insets = new Insets(6,6,6,6); gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx=0; gbc.gridy=0; p.add(new JLabel("Nome:"), gbc);
        txtNome = new JTextField(); gbc.gridx=1; gbc.weightx=1; p.add(txtNome, gbc); gbc.weightx=0;

        gbc.gridx=0; gbc.gridy=1; p.add(new JLabel("CPF:"), gbc);
        try { txtCpf = new JFormattedTextField(new MaskFormatter("###.###.###-##")); } catch (ParseException e){ txtCpf = new JFormattedTextField(); }
        gbc.gridx=1; p.add(txtCpf, gbc);

        gbc.gridx=0; gbc.gridy=2; p.add(new JLabel("Data Nasc (dd/MM/yyyy):"), gbc);
        try { txtDataNasc = new JFormattedTextField(new MaskFormatter("##/##/####")); } catch (ParseException e) { txtDataNasc = new JFormattedTextField(); }
        gbc.gridx=1; p.add(txtDataNasc, gbc);

        gbc.gridx=0; gbc.gridy=3; p.add(new JLabel("Telefone:"), gbc);
        txtTelefone = new JTextField(); gbc.gridx=1; p.add(txtTelefone, gbc);

        gbc.gridx=0; gbc.gridy=4; p.add(new JLabel("Email:"), gbc);
        txtEmail = new JTextField(); gbc.gridx=1; p.add(txtEmail, gbc);

        gbc.gridx=0; gbc.gridy=5; p.add(new JLabel("Plano:"), gbc);
        comboPlano = new JComboBox<>(); gbc.gridx=1; p.add(comboPlano, gbc);

        gbc.gridx=0; gbc.gridy=6; p.add(new JLabel("Objetivo:"), gbc);
        txtObjetivo = new JTextField(); gbc.gridx=1; p.add(txtObjetivo, gbc);

        gbc.gridx=0; gbc.gridy=7; p.add(new JLabel("Status:"), gbc);
        comboStatus = new JComboBox<>(new String[]{"Ativo","Inativo","Trancado","Avaliação"}); gbc.gridx=1; p.add(comboStatus, gbc);

        gbc.gridx=0; gbc.gridy=8; p.add(new JLabel("Data Matrícula (dd/MM/yyyy):"), gbc);
        try { txtDataMatricula = new JFormattedTextField(new MaskFormatter("##/##/####")); } catch (ParseException e) { txtDataMatricula = new JFormattedTextField(); }
        gbc.gridx=1; p.add(txtDataMatricula, gbc);

        JButton btnSalvar = new JButton("Salvar"); JButton btnCancelar = new JButton("Cancelar");
        parent.estilizarBotao(btnSalvar); parent.estilizarBotao(btnCancelar);
        gbc.gridx=0; gbc.gridy=9; gbc.gridwidth=2; p.add(btnSalvar, gbc);

        btnSalvar.addActionListener(e -> salvar());
        btnCancelar.addActionListener(e -> { dispose(); });

        carregarPlanos();

        if (aluno != null) carregarAluno();

    }

    private void carregarPlanos() {
        comboPlano.removeAllItems();
        List<Plano> planos = planoDAO.listarTodos();
        for (Plano p : planos) comboPlano.addItem(p);
    }

    private void carregarAluno() {
        txtNome.setText(aluno.getNome());
        txtCpf.setText(aluno.getCpf());
        if (aluno.getDataNascimento() != null) txtDataNasc.setText(aluno.getDataNascimento().format(df));
        txtTelefone.setText(aluno.getTelefone());
        txtEmail.setText(aluno.getEmail());
        txtObjetivo.setText(aluno.getObjetivo());
        comboStatus.setSelectedItem(aluno.getStatus());
        if (aluno.getDataMatricula() != null) txtDataMatricula.setText(aluno.getDataMatricula().format(df));
        // seleciona plano
        if (aluno.getPlanoId() > 0) {
            for (int i=0;i<comboPlano.getItemCount();i++) {
                Plano p = comboPlano.getItemAt(i);
                if (p != null && p.getId() == aluno.getPlanoId()) { comboPlano.setSelectedIndex(i); break; }
            }
        }
    }

    private void salvar() {
        String nome = txtNome.getText().trim();
        String cpf = txtCpf.getText().replaceAll("[.-]","").trim();
        String dataNascStr = txtDataNasc.getText().trim();
        String dataMatStr = txtDataMatricula.getText().trim();
        String telefone = txtTelefone.getText().trim();
        String email = txtEmail.getText().trim();
        String objetivo = txtObjetivo.getText().trim();
        String status = (String) comboStatus.getSelectedItem();
        Plano plano = (Plano) comboPlano.getSelectedItem();

        if (nome.isEmpty() || cpf.isEmpty()) { JOptionPane.showMessageDialog(this, "Nome e CPF obrigatórios"); return; }

        LocalDate dataNasc = null;
        LocalDate dataMat = null;
        DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try { if (!dataNascStr.isEmpty()) dataNasc = LocalDate.parse(dataNascStr, df); } catch (Exception ex){ JOptionPane.showMessageDialog(this, "Data nascimento inválida"); return; }
        try { if (!dataMatStr.isEmpty()) dataMat = LocalDate.parse(dataMatStr, df); } catch (Exception ex){ JOptionPane.showMessageDialog(this, "Data matrícula inválida"); return; }

        if (aluno == null) aluno = new Aluno();
        aluno.setNome(nome);
        aluno.setCpf(cpf);
        aluno.setDataNascimento(dataNasc);
        aluno.setTelefone(telefone);
        aluno.setEmail(email);
        aluno.setObjetivo(objetivo);
        aluno.setStatus(status);
        aluno.setDataMatricula(dataMat);
        aluno.setPlanoId(plano != null ? plano.getId() : 0);

        boolean ok;
        if (aluno.getId() == 0) {
            ok = alunoDAO.cadastrar(aluno);
            if (ok) JOptionPane.showMessageDialog(this, "Aluno cadastrado com sucesso!");
        } else {
            ok = alunoDAO.atualizar(aluno);
            if (ok) JOptionPane.showMessageDialog(this, "Aluno atualizado com sucesso!");
        }
        if (ok) {
            parent.atualizarTabela();
            dispose();
        }
    }
}

