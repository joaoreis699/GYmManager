package br.com.gymmanager.view;

import br.com.gymmanager.dao.AlunoDAO;
import br.com.gymmanager.dao.PlanoDAO;
import br.com.gymmanager.model.Aluno;
import br.com.gymmanager.model.Plano;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TelaGestaoAlunos extends JFrame {

    private static final Color COR_FUNDO = new Color(240, 242, 245);
    private static final Color COR_AZUL_PRINCIPAL = new Color(30, 90, 200);
    private static final Color COR_BRANCO = Color.WHITE;
    private static final Color COR_TEXTO_PADRAO = new Color(80, 80, 80);

    private AlunoDAO alunoDAO = new AlunoDAO();
    private PlanoDAO planoDAO = new PlanoDAO();
    private DefaultTableModel modelo;
    private JTable tabela;
    private DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public TelaGestaoAlunos(JFrame telaAnterior) {
        setTitle("GymManager — Gestão de Alunos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        JPanel painelFundo = new JPanel(new BorderLayout(20,20));
        painelFundo.setBackground(COR_FUNDO);
        painelFundo.setBorder(new EmptyBorder(20,20,20,20));
        setContentPane(painelFundo);

        JLabel titulo = new JLabel("Gestão de Alunos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(COR_AZUL_PRINCIPAL);
        painelFundo.add(titulo, BorderLayout.NORTH);

        // top: busca + botoes
        JPanel top = new JPanel(new BorderLayout(10,0)); top.setOpaque(false);
        JTextField txtBusca = new JTextField();
        txtBusca.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JButton btnBuscar = new JButton("Buscar");
        estilizarBotao(btnBuscar);
        top.add(txtBusca, BorderLayout.CENTER);
        top.add(btnBuscar, BorderLayout.EAST);
        painelFundo.add(top, BorderLayout.NORTH);

        // tabela
        String[] col = {"ID","Nome","CPF","Matricula","Status","Objetivo","Plano"};
        modelo = new DefaultTableModel(col,0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(28);
        JScrollPane sc = new JScrollPane(tabela);
        painelFundo.add(sc, BorderLayout.CENTER);

        // botoes
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        botoes.setOpaque(false);
        JButton btnAdd = new JButton("Adicionar");
        JButton btnEditar = new JButton("Editar");
        JButton btnRemover = new JButton("Remover");
        JButton btnPlanos = new JButton("Planos");
        JButton btnFicha = new JButton("Gerar Ficha");
        JButton btnVoltar = new JButton("Voltar");

        estilizarBotao(btnAdd); estilizarBotao(btnEditar); estilizarBotao(btnRemover);
        estilizarBotao(btnPlanos); estilizarBotao(btnFicha); estilizarBotao(btnVoltar);

        botoes.add(btnPlanos); botoes.add(btnAdd); botoes.add(btnEditar); botoes.add(btnRemover); botoes.add(btnFicha); botoes.add(btnVoltar);
        painelFundo.add(botoes, BorderLayout.SOUTH);

        // ações
        btnPlanos.addActionListener(e -> new TelaGestaoPlanos(this).setVisible(true));
        btnAdd.addActionListener(e -> new TelaCadastroAluno(this, null).setVisible(true));
        btnEditar.addActionListener(e -> {
            int sel = tabela.getSelectedRow();
            if (sel >= 0) {
                int id = (int) modelo.getValueAt(sel,0);
                Aluno a = alunoDAO.listarTodos().stream().filter(x -> x.getId() == id).findFirst().orElse(null);
                if (a != null) new TelaCadastroAluno(this, a).setVisible(true);
            } else JOptionPane.showMessageDialog(this, "Selecione um aluno.");
        });
        btnRemover.addActionListener(e -> {
            int sel = tabela.getSelectedRow();
            if (sel >= 0) {
                int id = (int) modelo.getValueAt(sel,0);
                if (JOptionPane.showConfirmDialog(this, "Remover aluno?") == JOptionPane.YES_OPTION) {
                    if (alunoDAO.remover(id)) atualizarTabela();
                }
            } else JOptionPane.showMessageDialog(this, "Selecione um aluno.");
        });
        btnFicha.addActionListener(e -> {
            int sel = tabela.getSelectedRow();
            if (sel >= 0) {
                int id = (int) modelo.getValueAt(sel,0);
                Aluno a = alunoDAO.listarTodos().stream().filter(x -> x.getId() == id).findFirst().orElse(null);
                if (a != null) new TelaGerarFichaTreino(this, a).setVisible(true);
            } else JOptionPane.showMessageDialog(this, "Selecione um aluno.");
        });
        btnVoltar.addActionListener(e -> {
            if (telaAnterior != null) telaAnterior.setVisible(true);
            dispose();
        });

        btnBuscar.addActionListener(e -> atualizarTabelaComFiltro(txtBusca.getText().trim()));
        txtBusca.addActionListener(e -> atualizarTabelaComFiltro(txtBusca.getText().trim()));

        atualizarTabela();
    }

    public void atualizarTabela() {
        atualizarTabelaComFiltro("");
    }

    public void atualizarTabelaComFiltro(String filtro) {
        modelo.setRowCount(0);
        List<Aluno> alunos = alunoDAO.listarTodos();
        for (Aluno a : alunos) {
            if (filtro.isEmpty() || a.getNome().toLowerCase().contains(filtro.toLowerCase()) || a.getCpf().contains(filtro)) {
                String matricula = a.getDataMatricula() != null ? a.getDataMatricula().format(df) : "N/A";
                String planoNome = "N/A";
                if (a.getPlanoId() > 0) {
                    Plano p = planoDAO.buscarPorId(a.getPlanoId());
                    if (p != null) planoNome = p.getNome();
                }
                modelo.addRow(new Object[]{a.getId(), a.getNome(), a.getCpf(), matricula, a.getStatus(), a.getObjetivo(), planoNome});
            }
        }
    }

    public void estilizarBotao(JButton botao) {
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
        botao.setBackground(COR_BRANCO);
        botao.setForeground(COR_TEXTO_PADRAO);
        botao.setFocusPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1,1,1,1,new Color(200,200,200)),
                new EmptyBorder(8,12,8,12)
        ));
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                botao.setBackground(COR_AZUL_PRINCIPAL); botao.setForeground(Color.WHITE);
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                botao.setBackground(COR_BRANCO); botao.setForeground(COR_TEXTO_PADRAO);
            }
        });
    }
}
