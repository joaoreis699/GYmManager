package br.com.gymmanager.model;

public class Exercicio {
    private int id;
    private int treinoId;
    private String nome;
    private int series;
    private int repeticoes;
    private double carga;

    public Exercicio() {}

    // getters / setters
    public int getId() { return id; } public void setId(int id) { this.id = id; }
    public int getTreinoId() { return treinoId; } public void setTreinoId(int treinoId) { this.treinoId = treinoId; }
    public String getNome() { return nome; } public void setNome(String nome) { this.nome = nome; }
    public int getSeries() { return series; } public void setSeries(int series) { this.series = series; }
    public int getRepeticoes() { return repeticoes; } public void setRepeticoes(int repeticoes) { this.repeticoes = repeticoes; }
    public double getCarga() { return carga; } public void setCarga(double carga) { this.carga = carga; }
}
