package br.com.gymmanager.view;

import br.com.gymmanager.dao.ExercicioDAO;
import br.com.gymmanager.dao.TreinoDAO;
import br.com.gymmanager.model.Aluno;
import br.com.gymmanager.model.Exercicio;
import br.com.gymmanager.model.Treino;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class TelaGerarFichaTreino extends JFrame {

    private static final Color COR_FUNDO = new Color(240, 242, 245);
    private static final Color COR_AZUL_PRINCIPAL = new Color(30, 90, 200);
    private static final Color COR_BRANCO = Color.WHITE;
    private static final Color COR_TEXTO_PADRAO = new Color(80, 80, 80);

    private TreinoDAO treinoDAO = new TreinoDAO();
    private ExercicioDAO exercDAO = new ExercicioDAO();

    private Aluno aluno;
    private DefaultTableModel modeloTreinos;
    private DefaultTableModel modeloExs;
    private JTable tabelaTreinos;
    private JTable tabelaExs;

    public TelaGerarFichaTreino(JFrame telaAnterior, Aluno aluno) {
        this.aluno = aluno;
        setTitle("Gerar Ficha — " + (aluno != null ? aluno.getNome() : ""));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        JPanel fundo = new JPanel(new BorderLayout(20,20));
        fundo.setBackground(COR_FUNDO);
        fundo.setBorder(new EmptyBorder(20,20,20,20));
        setContentPane(fundo);

        JLabel titulo = new JLabel("Gerar Ficha de Treino — " + (aluno != null ? aluno.getNome() : ""));
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(COR_AZUL_PRINCIPAL);
        fundo.add(titulo, BorderLayout.NORTH);

        // Centro: treinos (esq) | exercicios (dir)
        JPanel centro = new JPanel(new GridLayout(1,2,20,0));
        centro.setOpaque(false);

        // Treinos
        JPanel pTreinos = new JPanel(new BorderLayout(10,10));
        pTreinos.setOpaque(false);
        modeloTreinos = new DefaultTableModel(new String[]{"ID","Nome","Data"},0);
        tabelaTreinos = new JTable(modeloTreinos);
        tabelaTreinos.setRowHeight(28);
        pTreinos.add(new JScrollPane(tabelaTreinos), BorderLayout.CENTER);

        JPanel btnsT = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAddT = new JButton("Adicionar Treino");
        JButton btnRemT = new JButton("Remover Treino");
        estilizar(btnAddT); estilizar(btnRemT);
        btnsT.add(btnAddT); btnsT.add(btnRemT);
        pTreinos.add(btnsT, BorderLayout.SOUTH);

        // Exercicios
        JPanel pExs = new JPanel(new BorderLayout(10,10));
        pExs.setOpaque(false);
        modeloExs = new DefaultTableModel(new String[]{"ID","Nome","Séries","Rep.","Carga"},0);
        tabelaExs = new JTable(modeloExs);
        tabelaExs.setRowHeight(28);
        pExs.add(new JScrollPane(tabelaExs), BorderLayout.CENTER);

        JPanel btnsE = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAddE = new JButton("Adicionar Exercicio");
        JButton btnRemE = new JButton("Remover Exercicio");
        estilizar(btnAddE); estilizar(btnRemE);
        btnsE.add(btnAddE); btnsE.add(btnRemE);
        pExs.add(btnsE, BorderLayout.SOUTH);

        centro.add(pTreinos); centro.add(pExs);
        fundo.add(centro, BorderLayout.CENTER);

        // Bottom: Salvar / Voltar
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setOpaque(false);
        JButton btnSalvar = new JButton("Salvar Ficha");
        JButton btnVoltar = new JButton("Voltar");
        estilizar(btnSalvar); estilizar(btnVoltar);
        bottom.add(btnSalvar); bottom.add(btnVoltar);
        fundo.add(bottom, BorderLayout.SOUTH);

        // ações
        btnAddT.addActionListener(e -> {
            String nome = JOptionPane.showInputDialog(this, "Nome do treino (ex: Treino A):");
            if (nome != null && !nome.trim().isEmpty()) {
                Treino t = new Treino();
                t.setAlunoId(aluno.getId());
                t.setNome(nome.trim());
                t.setDataCriacao(LocalDate.now());
                if (treinoDAO.cadastrar(t)) atualizarTreinos();
            }
        });

        btnRemT.addActionListener(e -> {
            int sel = tabelaTreinos.getSelectedRow();
            if (sel >= 0) {
                int id = (int) modeloTreinos.getValueAt(sel, 0);
                if (treinoDAO.remover(id)) atualizarTreinos();
            } else JOptionPane.showMessageDialog(this, "Selecione um treino.");
        });

        btnAddE.addActionListener(e -> {
            int sel = tabelaTreinos.getSelectedRow();
            if (sel < 0) { JOptionPane.showMessageDialog(this, "Selecione um treino antes."); return;}
            int treinoId = (int) modeloTreinos.getValueAt(sel,0);
            // pedir dados do exercício
            String nome = JOptionPane.showInputDialog(this, "Nome do exercício:");
            if (nome == null || nome.trim().isEmpty()) return;
            String sSeries = JOptionPane.showInputDialog(this, "Séries:");
            String sRep = JOptionPane.showInputDialog(this, "Repetições:");
            String sCarga = JOptionPane.showInputDialog(this, "Carga (kg):");
            try {
                int series = Integer.parseInt(sSeries);
                int reps = Integer.parseInt(sRep);
                double carga = Double.parseDouble(sCarga.replace(",","."));
                Exercicio ex = new Exercicio();
                ex.setTreinoId(treinoId);
                ex.setNome(nome.trim());
                ex.setSeries(series);
                ex.setRepeticoes(reps);
                ex.setCarga(carga);
                if (exercDAO.cadastrar(ex)) atualizarExs(treinoId);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Dados inválidos para o exercício.");
            }
        });

        btnRemE.addActionListener(e -> {
            int sel = tabelaExs.getSelectedRow();
            if (sel >= 0) {
                int id = (int) modeloExs.getValueAt(sel,0);
                if (exercDAO.remover(id)) {
                    int treinoSel = tabelaTreinos.getSelectedRow();
                    if (treinoSel >= 0) {
                        int treinoId = (int) modeloTreinos.getValueAt(treinoSel,0);
                        atualizarExs(treinoId);
                    }
                }
            } else JOptionPane.showMessageDialog(this, "Selecione um exercício.");
        });

        tabelaTreinos.getSelectionModel().addListSelectionListener(ev -> {
            int sel = tabelaTreinos.getSelectedRow();
            if (sel >= 0) {
                int treinoId = (int) modeloTreinos.getValueAt(sel,0);
                atualizarExs(treinoId);
            } else modeloExs.setRowCount(0);
        });

        btnSalvar.addActionListener(e -> JOptionPane.showMessageDialog(this, "Ficha salva (já persistida pelo DAO)."));
        btnVoltar.addActionListener(e -> { if (telaAnterior != null) telaAnterior.setVisible(true); dispose(); });

        atualizarTreinos();
    }

    private void atualizarTreinos() {
        modeloTreinos.setRowCount(0);
        List<Treino> lista = treinoDAO.listarPorAluno(aluno.getId());
        for (Treino t : lista) {
            modeloTreinos.addRow(new Object[]{t.getId(), t.getNome(), t.getDataCriacao()});
        }
    }

    private void atualizarExs(int treinoId) {
        modeloExs.setRowCount(0);
        List<Exercicio> lista = exercDAO.listarPorTreino(treinoId);
        for (Exercicio ex : lista) {
            modeloExs.addRow(new Object[]{ex.getId(), ex.getNome(), ex.getSeries(), ex.getRepeticoes(), ex.getCarga()});
        }
    }

    private void estilizar(JButton b) {
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(COR_BRANCO);
        b.setForeground(COR_TEXTO_PADRAO);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1,1,1,1,new Color(200,200,200)),
                new EmptyBorder(6,10,6,10)
        ));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(COR_AZUL_PRINCIPAL); b.setForeground(Color.WHITE); }
            @Override public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(COR_BRANCO); b.setForeground(COR_TEXTO_PADRAO); }
        });
    }
}
