package br.com.gymmanager.model;

import java.time.LocalDate;

public class Treino {
    private int id;
    private int alunoId;
    private String nome; // ex: Treino A
    private LocalDate dataCriacao;

    public Treino() {}
    public Treino(int id, int alunoId, String nome, LocalDate dataCriacao) {
        this.id = id; this.alunoId = alunoId; this.nome = nome; this.dataCriacao = dataCriacao;
    }

    // getters / setters
    public int getId() { return id; } public void setId(int id) { this.id = id; }
    public int getAlunoId() { return alunoId; } public void setAlunoId(int alunoId) { this.alunoId = alunoId; }
    public String getNome() { return nome; } public void setNome(String nome) { this.nome = nome; }
    public LocalDate getDataCriacao() { return dataCriacao; } public void setDataCriacao(LocalDate dataCriacao) { this.dataCriacao = dataCriacao; }
}
