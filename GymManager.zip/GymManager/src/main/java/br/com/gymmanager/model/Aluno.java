package br.com.gymmanager.model;

import java.time.LocalDate;

/**
 * Entidade Aluno, herda atributos básicos (nome, cpf, dataNascimento)
 * da classe Pessoa.
 */
public class Aluno extends Pessoa {
    
    private int id;
    private LocalDate dataMatricula;
    private String status; // Ex: Ativo, Inativo, Trancado, Avaliação
    private String objetivo; // Ex: Hipertrofia, Emagrecimento, Condicionamento
    private int planoId; // Chave estrangeira para a tabela de Planos
    
    // Construtor Vazio
    public Aluno() {
        super();
    }
    
    // Construtor Completo
    public Aluno(
            String nome, String cpf, LocalDate dataNascimento, String telefone, String email,
            int id, LocalDate dataMatricula, String status, String objetivo, int planoId) {
        
        super(nome, dataNascimento, cpf, telefone, email);
        this.id = id;
        this.dataMatricula = dataMatricula;
        this.status = status;
        this.objetivo = objetivo;
        this.planoId = planoId;
    }
    
    // --- Getters e Setters ---
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getDataMatricula() {
        return dataMatricula;
    }

    public void setDataMatricula(LocalDate dataMatricula) {
        this.dataMatricula = dataMatricula;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public int getPlanoId() {
        return planoId;
    }

    public void setPlanoId(int planoId) {
        this.planoId = planoId;
    }
    
    // Opcional: Para facilitar a visualização de log
    @Override
    public String toString() {
        return "Aluno{" +
                "id=" + id +
                ", nome='" + getNome() + '\'' +
                ", cpf='" + getCpf() + '\'' +
                ", dataMatricula=" + dataMatricula +
                ", status='" + status + '\'' +
                '}';
    }
}