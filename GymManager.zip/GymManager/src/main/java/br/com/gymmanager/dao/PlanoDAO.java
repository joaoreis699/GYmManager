package br.com.gymmanager.dao;

import br.com.gymmanager.model.Plano;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PlanoDAO {

    public boolean cadastrar(Plano plano) {
        String sql = "INSERT INTO planos (nome, duracao_meses, valor, descricao) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {

            pstm.setString(1, plano.getNome());
            pstm.setInt(2, plano.getDuracaoMeses());
            pstm.setDouble(3, plano.getValor());
            pstm.setString(4, plano.getDescricao());
            pstm.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar plano: " + e.getMessage());
            return false;
        }
    }

    public boolean atualizar(Plano plano) {
        String sql = "UPDATE planos SET nome = ?, duracao_meses = ?, valor = ?, descricao = ? WHERE id_plano = ?";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {

            pstm.setString(1, plano.getNome());
            pstm.setInt(2, plano.getDuracaoMeses());
            pstm.setDouble(3, plano.getValor());
            pstm.setString(4, plano.getDescricao());
            pstm.setInt(5, plano.getId());
            pstm.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar plano: " + e.getMessage());
            return false;
        }
    }

    public boolean remover(int id) {
        String sql = "DELETE FROM planos WHERE id_plano = ?";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {

            pstm.setInt(1, id);
            pstm.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover plano: " + e.getMessage());
            return false;
        }
    }

    public List<Plano> listarTodos() {
        List<Plano> lista = new ArrayList<>();
        String sql = "SELECT * FROM planos";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql);
             ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {
                Plano p = new Plano();
                p.setId(rs.getInt("id_plano"));
                p.setNome(rs.getString("nome"));
                p.setDuracaoMeses(rs.getInt("duracao_meses"));
                p.setValor(rs.getDouble("valor"));
                p.setDescricao(rs.getString("descricao"));
                lista.add(p);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar planos: " + e.getMessage());
        }
        return lista;
    }

    public Plano buscarPorId(int id) {
        String sql = "SELECT * FROM planos WHERE id_plano = ?";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, id);
            try (ResultSet rs = pstm.executeQuery()) {
                if (rs.next()) {
                    Plano p = new Plano();
                    p.setId(rs.getInt("id_plano"));
                    p.setNome(rs.getString("nome"));
                    p.setDuracaoMeses(rs.getInt("duracao_meses"));
                    p.setValor(rs.getDouble("valor"));
                    p.setDescricao(rs.getString("descricao"));
                    return p;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar plano: " + e.getMessage());
        }
        return null;
    }
}
