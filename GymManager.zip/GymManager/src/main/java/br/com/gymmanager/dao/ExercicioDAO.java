package br.com.gymmanager.dao;

import br.com.gymmanager.model.Exercicio;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ExercicioDAO {

    public boolean cadastrar(Exercicio ex) {
        String sql = "INSERT INTO exercicios (treino_id, nome, series, repeticoes, carga) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstm.setInt(1, ex.getTreinoId());
            pstm.setString(2, ex.getNome());
            pstm.setInt(3, ex.getSeries());
            pstm.setInt(4, ex.getRepeticoes());
            pstm.setDouble(5, ex.getCarga());
            pstm.execute();
            try (ResultSet rs = pstm.getGeneratedKeys()) {
                if (rs.next()) ex.setId(rs.getInt(1));
            }
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar exercício: " + e.getMessage());
            return false;
        }
    }

    public List<Exercicio> listarPorTreino(int treinoId) {
        List<Exercicio> lista = new ArrayList<>();
        String sql = "SELECT * FROM exercicios WHERE treino_id = ? ORDER BY id_exercicio ASC";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, treinoId);
            try (ResultSet rs = pstm.executeQuery()) {
                while (rs.next()) {
                    Exercicio ex = new Exercicio();
                    ex.setId(rs.getInt("id_exercicio"));
                    ex.setTreinoId(rs.getInt("treino_id"));
                    ex.setNome(rs.getString("nome"));
                    ex.setSeries(rs.getInt("series"));
                    ex.setRepeticoes(rs.getInt("repeticoes"));
                    ex.setCarga(rs.getDouble("carga"));
                    lista.add(ex);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar exercícios: " + e.getMessage());
        }
        return lista;
    }

    public boolean remover(int id) {
        String sql = "DELETE FROM exercicios WHERE id_exercicio = ?";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, id);
            pstm.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover exercício: " + e.getMessage());
            return false;
        }
    }
}
