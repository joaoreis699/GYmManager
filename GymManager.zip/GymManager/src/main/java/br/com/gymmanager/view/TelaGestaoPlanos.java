package br.com.gymmanager.view;

import br.com.gymmanager.dao.PlanoDAO;
import br.com.gymmanager.model.Plano;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaGestaoPlanos extends JFrame {

    private static final Color COR_FUNDO = new Color(240, 242, 245);
    private static final Color COR_AZUL_PRINCIPAL = new Color(30, 90, 200);
    private static final Color COR_BRANCO = Color.WHITE;
    private static final Color COR_TEXTO_PADRAO = new Color(80, 80, 80);

    private PlanoDAO planoDAO = new PlanoDAO();
    private DefaultTableModel modelo;
    private JTable tabela;

    public TelaGestaoPlanos(JFrame telaAnterior) {
        setTitle("GymManager — Gestão de Planos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        JPanel painelFundo = new JPanel(new BorderLayout(20, 20));
        painelFundo.setBackground(COR_FUNDO);
        painelFundo.setBorder(new EmptyBorder(20,20,20,20));
        setContentPane(painelFundo);

        JLabel titulo = new JLabel("Gestão de Planos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(COR_AZUL_PRINCIPAL);
        painelFundo.add(titulo, BorderLayout.NORTH);

        // tabela
        String[] col = {"ID", "Nome", "Duração (meses)", "Valor", "Descrição"};
        modelo = new DefaultTableModel(col, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(28);
        JScrollPane scroll = new JScrollPane(tabela);
        painelFundo.add(scroll, BorderLayout.CENTER);

        // botoes
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        botoes.setOpaque(false);
        JButton btnAdd = new JButton("Adicionar");
        JButton btnEditar = new JButton("Editar");
        JButton btnRemover = new JButton("Remover");
        JButton btnVoltar = new JButton("Voltar");

        estilizarBotao(btnAdd); estilizarBotao(btnEditar); estilizarBotao(btnRemover); estilizarBotao(btnVoltar);
        botoes.add(btnAdd); botoes.add(btnEditar); botoes.add(btnRemover); botoes.add(btnVoltar);
        painelFundo.add(botoes, BorderLayout.SOUTH);

        btnAdd.addActionListener(e -> abrirCadastroPlano(null));
        btnEditar.addActionListener(e -> {
            int sel = tabela.getSelectedRow();
            if (sel >= 0) {
                int id = (int) modelo.getValueAt(sel, 0);
                Plano p = planoDAO.buscarPorId(id);
                abrirCadastroPlano(p);
            } else JOptionPane.showMessageDialog(this, "Selecione um plano.");
        });
        btnRemover.addActionListener(e -> {
            int sel = tabela.getSelectedRow();
            if (sel >= 0) {
                int id = (int) modelo.getValueAt(sel, 0);
                if (JOptionPane.showConfirmDialog(this, "Remover plano?") == JOptionPane.YES_OPTION) {
                    if (planoDAO.remover(id)) atualizarTabela();
                }
            } else JOptionPane.showMessageDialog(this, "Selecione um plano.");
        });
        btnVoltar.addActionListener(e -> {
            if (telaAnterior != null) telaAnterior.setVisible(true);
            dispose();
        });

        atualizarTabela();
    }

    private void atualizarTabela() {
        modelo.setRowCount(0);
        List<Plano> planos = planoDAO.listarTodos();
        for (Plano p : planos) {
            modelo.addRow(new Object[]{p.getId(), p.getNome(), p.getDuracaoMeses(), p.getValor(), p.getDescricao()});
        }
    }

    private void abrirCadastroPlano(Plano plano) {
        JFrame janela = new JFrame(plano == null ? "Cadastrar Plano" : "Editar Plano");
        janela.setSize(500, 400);
        janela.setLocationRelativeTo(this);
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(new EmptyBorder(15,15,15,15));
        janela.setContentPane(p);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL; gbc.insets = new Insets(8,8,8,8);

        gbc.gridx=0; gbc.gridy=0; p.add(new JLabel("Nome:"), gbc);
        JTextField txtNome = new JTextField(); gbc.gridx=1; gbc.weightx=1; p.add(txtNome, gbc);
        gbc.weightx=0;

        gbc.gridx=0; gbc.gridy=1; p.add(new JLabel("Duração (meses):"), gbc);
        JTextField txtDur = new JTextField(); gbc.gridx=1; p.add(txtDur, gbc);

        gbc.gridx=0; gbc.gridy=2; p.add(new JLabel("Valor:"), gbc);
        JTextField txtValor = new JTextField(); gbc.gridx=1; p.add(txtValor, gbc);

        gbc.gridx=0; gbc.gridy=3; p.add(new JLabel("Descrição:"), gbc);
        JTextArea txtDesc = new JTextArea(4,20); JScrollPane sc = new JScrollPane(txtDesc);
        gbc.gridx=1; p.add(sc, gbc);

        JButton btnSalvar = new JButton("Salvar");
        estilizarBotao(btnSalvar);
        gbc.gridx=0; gbc.gridy=4; gbc.gridwidth=2; p.add(btnSalvar, gbc);

        if (plano != null) {
            txtNome.setText(plano.getNome());
            txtDur.setText(String.valueOf(plano.getDuracaoMeses()));
            txtValor.setText(String.valueOf(plano.getValor()));
            txtDesc.setText(plano.getDescricao());
        }

        btnSalvar.addActionListener(ev -> {
            String nome = txtNome.getText().trim();
            int dur = 0; double valor = 0;
            try { dur = Integer.parseInt(txtDur.getText().trim()); } catch (Exception ex) {}
            try { valor = Double.parseDouble(txtValor.getText().replace(",", ".").trim()); } catch (Exception ex) {}

            if (nome.isEmpty()) { JOptionPane.showMessageDialog(janela, "Nome obrigatório"); return; }

            if (plano == null) {
                Plano pnew = new Plano(0, nome, dur, valor, txtDesc.getText().trim());
                if (new PlanoDAO().cadastrar(pnew)) {
                    JOptionPane.showMessageDialog(janela, "Plano cadastrado");
                    janela.dispose();
                    atualizarTabela();
                }
            } else {
                plano.setNome(nome); plano.setDuracaoMeses(dur); plano.setValor(valor); plano.setDescricao(txtDesc.getText().trim());
                if (new PlanoDAO().atualizar(plano)) {
                    JOptionPane.showMessageDialog(janela, "Plano atualizado");
                    janela.dispose();
                    atualizarTabela();
                }
            }
        });

        janela.setVisible(true);
    }

    private void estilizarBotao(JButton botao) {
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
        botao.setBackground(COR_BRANCO);
        botao.setForeground(COR_TEXTO_PADRAO);
        botao.setFocusPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1,1,1,1,new Color(200,200,200)),
                new EmptyBorder(8,12,8,12)
        ));
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                botao.setBackground(COR_AZUL_PRINCIPAL); botao.setForeground(Color.WHITE);
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                botao.setBackground(COR_BRANCO); botao.setForeground(COR_TEXTO_PADRAO);
            }
        });
    }
}
