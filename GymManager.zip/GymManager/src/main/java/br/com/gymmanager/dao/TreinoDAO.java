package br.com.gymmanager.dao;

import br.com.gymmanager.model.Treino;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TreinoDAO {

    public boolean cadastrar(Treino t) {
        String sql = "INSERT INTO treinos (aluno_id, nome, data_criacao) VALUES (?, ?, ?)";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstm.setInt(1, t.getAlunoId());
            pstm.setString(2, t.getNome());
            pstm.setDate(3, Date.valueOf(t.getDataCriacao()));
            pstm.execute();
            try (ResultSet rs = pstm.getGeneratedKeys()) {
                if (rs.next()) t.setId(rs.getInt(1));
            }
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar treino: " + e.getMessage());
            return false;
        }
    }

    public List<Treino> listarPorAluno(int alunoId) {
        List<Treino> lista = new ArrayList<>();
        String sql = "SELECT * FROM treinos WHERE aluno_id = ?";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, alunoId);
            try (ResultSet rs = pstm.executeQuery()) {
                while (rs.next()) {
                    Treino t = new Treino();
                    t.setId(rs.getInt("id_treino"));
                    t.setAlunoId(rs.getInt("aluno_id"));
                    Date d = rs.getDate("data_criacao");
                    if (d != null) t.setDataCriacao(d.toLocalDate());
                    t.setNome(rs.getString("nome"));
                    lista.add(t);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar treinos: " + e.getMessage());
        }
        return lista;
    }

    public boolean remover(int id) {
        String sql = "DELETE FROM treinos WHERE id_treino = ?";
        try (Connection conn = ConexaoDAO.getConexao();
             PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, id);
            pstm.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover treino: " + e.getMessage());
            return false;
        }
    }
}
