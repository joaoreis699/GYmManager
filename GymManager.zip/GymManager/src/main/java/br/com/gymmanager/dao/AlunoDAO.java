package br.com.gymmanager.dao;

import br.com.gymmanager.model.Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.sql.Date; // Para conversão JDBC

import javax.swing.JOptionPane;

public class AlunoDAO {

    // Método auxiliar para mapear o ResultSet para o objeto Aluno
    private Aluno mapResultSetToAluno(ResultSet rset) throws SQLException {
        Aluno aluno = new Aluno();
        aluno.setId(rset.getInt("id_aluno"));
        aluno.setNome(rset.getString("nome"));
        aluno.setCpf(rset.getString("cpf"));
        aluno.setTelefone(rset.getString("telefone"));
        aluno.setEmail(rset.getString("email"));

        // CONVERSÃO DE DATA: java.sql.Date -> LocalDate
        Date sqlDataNascimento = rset.getDate("data_nascimento");
        if (sqlDataNascimento != null) {
            aluno.setDataNascimento(sqlDataNascimento.toLocalDate());
        }

        // CONVERSÃO DE DATA: java.sql.Date -> LocalDate
        Date sqlDataMatricula = rset.getDate("data_matricula");
        if (sqlDataMatricula != null) {
            aluno.setDataMatricula(sqlDataMatricula.toLocalDate());
        }

        aluno.setStatus(rset.getString("status"));
        aluno.setObjetivo(rset.getString("objetivo"));
        aluno.setPlanoId(rset.getInt("plano_id"));
        
        return aluno;
    }

    public boolean cadastrar(Aluno aluno) {
        String sql = "INSERT INTO alunos (nome, cpf, data_nascimento, telefone, email, data_matricula, status, objetivo, plano_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);

            pstm.setString(1, aluno.getNome());
            pstm.setString(2, aluno.getCpf());
            
            // CONVERSÃO: LocalDate -> java.sql.Date
            LocalDate dataNasc = aluno.getDataNascimento();
            pstm.setDate(3, dataNasc != null ? Date.valueOf(dataNasc) : null);
            
            pstm.setString(4, aluno.getTelefone());
            pstm.setString(5, aluno.getEmail());
            
            // CONVERSÃO: LocalDate -> java.sql.Date
            LocalDate dataMatricula = aluno.getDataMatricula();
            pstm.setDate(6, dataMatricula != null ? Date.valueOf(dataMatricula) : null);

            pstm.setString(7, aluno.getStatus());
            pstm.setString(8, aluno.getObjetivo());
            pstm.setInt(9, aluno.getPlanoId());
            
            pstm.execute();
            return true;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar aluno: " + e.getMessage());
            return false;
        } finally {
            // Fechamento completo dos recursos
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean atualizar(Aluno aluno) {
        String sql = "UPDATE alunos SET nome = ?, cpf = ?, data_nascimento = ?, telefone = ?, email = ?, data_matricula = ?, status = ?, objetivo = ?, plano_id = ? " +
                     "WHERE id_aluno = ?";

        Connection conn = null;
        PreparedStatement pstm = null;

        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);

            pstm.setString(1, aluno.getNome());
            pstm.setString(2, aluno.getCpf());
            
            // CONVERSÃO: LocalDate -> java.sql.Date
            LocalDate dataNasc = aluno.getDataNascimento();
            pstm.setDate(3, dataNasc != null ? Date.valueOf(dataNasc) : null);
            
            pstm.setString(4, aluno.getTelefone());
            pstm.setString(5, aluno.getEmail());
            
            // CONVERSÃO: LocalDate -> java.sql.Date
            LocalDate dataMatricula = aluno.getDataMatricula();
            pstm.setDate(6, dataMatricula != null ? Date.valueOf(dataMatricula) : null);

            pstm.setString(7, aluno.getStatus());
            pstm.setString(8, aluno.getObjetivo());
            pstm.setInt(9, aluno.getPlanoId());
            pstm.setInt(10, aluno.getId());

            pstm.executeUpdate();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar aluno: " + e.getMessage());
            return false;
        } finally {
            // Fechamento completo dos recursos
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean remover(int id) {
        String sql = "DELETE FROM alunos WHERE id_aluno = ?";
        
        Connection conn = null;
        PreparedStatement pstm = null;

        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, id);
            pstm.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover aluno: " + e.getMessage());
            return false;
        } finally {
            // Fechamento completo dos recursos
            try {
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public List<Aluno> listarTodos() {
        String sql = "SELECT * FROM alunos";
        List<Aluno> alunos = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;

        try {
            conn = ConexaoDAO.getConexao();
            pstm = conn.prepareStatement(sql);
            rset = pstm.executeQuery();

            while(rset.next()) {
                alunos.add(mapResultSetToAluno(rset)); // Usa o método auxiliar
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar alunos: " + e.getMessage());
        } finally {
            // Fechamento completo dos recursos
            try {
                if (rset != null) rset.close();
                if (pstm != null) pstm.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return alunos;
    }
}