package br.com.gymmanager.model;

import java.time.LocalDate;

/**
 * @author joaoreis699
 */
public class Funcionario extends Pessoa {
    
    private int id; 
    private String cargo;
    private LocalDate dataAdmissao; // Já estava LocalDate
    private String senha;
    private String caminhoFoto;
    
    public Funcionario() {
        super();
    }
    
    // Construtor simplificado - AGORA RECEBE LocalDate
    public Funcionario(String nome, String cpf, LocalDate dataNascimento, int id, String cargo, LocalDate dataAdmissao, String senha, String caminhoFoto) {
        
        super(nome, dataNascimento, cpf); // Chamada correta: dataNascimento é LocalDate
        this.id = id;
        this.cargo = cargo;
        this.dataAdmissao = dataAdmissao;
        this.senha = senha;
        this.caminhoFoto = caminhoFoto;
    }
    
    // Construtor completo - AGORA RECEBE LocalDate
    public Funcionario(String nome, String cpf, LocalDate dataNascimento, int id, String telefone, String email, String cargo, LocalDate dataAdmissao, String senha, String caminhoFoto) {
        
        super(nome, dataNascimento, cpf, telefone, email); // Chamada correta: dataNascimento é LocalDate
        this.id = id;
        this.cargo = cargo;
        this.dataAdmissao = dataAdmissao;
        this.senha = senha;
        this.caminhoFoto = caminhoFoto;
    }
    
    // --- Getters e Setters ---
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getCargo() { return cargo; } 
    public void setCargo(String cargo) { this.cargo = cargo; }
    
    // GETTER DA DATA DE ADMISSÃO CORRIGIDO PARA LocalDate
    public LocalDate getDataAdmissao() { return dataAdmissao; }
    
    // SETTER DA DATA DE ADMISSÃO CORRIGIDO PARA LocalDate
    public void setDataAdmissao(LocalDate dataAdmissao) { this.dataAdmissao = dataAdmissao; }
    
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    
    public String getCaminhoFoto() { return caminhoFoto; }
    public void setCaminhoFoto(String caminhoFoto) { this.caminhoFoto = caminhoFoto; }

}